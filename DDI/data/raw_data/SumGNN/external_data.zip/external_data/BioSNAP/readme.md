This is the folder for BioSNAP data.

- `entity_drug.json`: the mapping between Hetionet entity and the node id in the graph
- `relation_type_drug.json`: the mapping between Hetionet relation and the relation id in the graph
- `id2drug.json`:  the mapping between node id in the graph (key) and the cid/drugbank id (if available)
- `id2relation.json`:  the mapping between relation id in the graph (key) and the relation id in the original dataset