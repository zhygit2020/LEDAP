This is the folder for BioSNAP data.

- `entity_drug.json`: the mapping between Hetionet entity and the node id in the graph
- `relation_type_drug.json`: the mapping between Hetionet relation and the relation id in the graph
- `node2id`:  the mapping between the drugbank id (key) and node id in the graph (if available)
- the mapping between relation id and relation name can be found at [this link](https://bitbucket.org/kaistsystemsbiology/deepddi/src/master/data/Interaction_information.csv).